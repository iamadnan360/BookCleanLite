# BookClean Lite

A tiny Android wrapper around Google ML Kit Document Scanner for the specific job of turning book photos into a clean PDF.

## Features

- Import photos from the gallery
- Automatic page edge detection / cropping
- Automatic upright rotation
- Full scanner mode with filters and image cleaning/auto-enhancement
- Reorder/remove pages before export
- Multi-page PDF output (configured for up to 500 pages per session)
- Automatically saves the generated PDF to `Downloads/BookClean`
- No camera permission requested by this app

## Target

Android 15 / Funtouch OS 15. `minSdk 21`, target SDK 35.

## Build

Open this folder in Android Studio. Use JDK 17 and let Gradle sync/download dependencies. Build the `release` APK.

Google Play services must be present because the Document Scanner models/UI are supplied by Google Play services.

## Sources for the scanner behavior

Google ML Kit Document Scanner documentation says it supports gallery import, accurate edge detection for cropping, automatic rotation detection, filters/image enhancement, and on-device processing. The current artifact is `com.google.android.gms:play-services-mlkit-document-scanner:16.0.0`.
