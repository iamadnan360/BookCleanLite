# ML Kit / Play services keep rules are supplied by their AARs.
