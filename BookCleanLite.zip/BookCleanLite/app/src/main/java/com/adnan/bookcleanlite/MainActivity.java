package com.adnan.bookcleanlite;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Tiny wrapper around Google ML Kit's on-device Document Scanner.
 * The scanner provides gallery import, accurate page-edge detection,
 * automatic upright rotation, filters/auto enhancement, and PDF output.
 */
public class MainActivity extends Activity {

    private static final int SCAN_REQUEST = 7001;
    private TextView status;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(18));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(getColor(com.adnan.bookcleanlite.R.color.paper));

        TextView title = new TextView(this);
        title.setText(getString(R.string.title));
        title.setTextSize(30);
        title.setTextColor(getColor(R.color.ink));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView subtitle = new TextView(this);
        subtitle.setText(getString(R.string.subtitle));
        subtitle.setTextSize(15);
        subtitle.setTextColor(getColor(R.color.muted));
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.bottomMargin = dp(22);
        root.addView(subtitle, subLp);

        TextView what = new TextView(this);
        what.setText(getString(R.string.how_title));
        what.setTextSize(18);
        what.setTextColor(getColor(R.color.ink));
        what.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(what, new LinearLayout.LayoutParams(-1, -2));

        TextView details = new TextView(this);
        details.setText(getString(R.string.how_text));
        details.setTextSize(15);
        details.setTextColor(getColor(R.color.muted));
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(-1, -2);
        dLp.topMargin = dp(8);
        dLp.bottomMargin = dp(28);
        root.addView(details, dLp);

        Button start = new Button(this);
        start.setText(getString(R.string.start));
        start.setAllCaps(false);
        start.setTextSize(16);
        start.setOnClickListener(v -> launchScanner());
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView note = new TextView(this);
        note.setText(getString(R.string.note));
        note.setTextSize(13);
        note.setTextColor(getColor(R.color.muted));
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(-1, -2);
        nLp.topMargin = dp(14);
        root.addView(note, nLp);

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(-2, -2);
        pLp.topMargin = dp(18);
        root.addView(progress, pLp);

        status = new TextView(this);
        status.setText("");
        status.setTextSize(14);
        status.setTextColor(getColor(R.color.ink));
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(-1, -2);
        sLp.topMargin = dp(12);
        root.addView(status, sLp);

        setContentView(root);
    }

    private void launchScanner() {
        GmsDocumentScannerOptions options = new GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(500) // comfortably above the user's 118-page batch
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build();

        GmsDocumentScanner scanner = GmsDocumentScanning.getClient(options);
        progress.setVisibility(View.VISIBLE);
        status.setText("Opening scanner…");

        scanner.getStartScanIntent(this)
                .addOnSuccessListener(new OnSuccessListener<android.content.IntentSender>() {
                    @Override
                    public void onSuccess(android.content.IntentSender intentSender) {
                        try {
                            startIntentSenderForResult(intentSender, SCAN_REQUEST, null, 0, 0, 0);
                        } catch (Exception e) {
                            progress.setVisibility(View.GONE);
                            status.setText("");
                            Toast.makeText(MainActivity.this, getString(R.string.failed), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        progress.setVisibility(View.GONE);
                        status.setText("");
                        Toast.makeText(MainActivity.this, getString(R.string.google_required), Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SCAN_REQUEST) return;

        progress.setVisibility(View.GONE);
        if (resultCode != RESULT_OK || data == null) {
            status.setText("");
            return;
        }

        GmsDocumentScanningResult result = GmsDocumentScanningResult.fromActivityResultIntent(data);
        if (result == null || result.getPdf() == null) {
            Toast.makeText(this, getString(R.string.failed), Toast.LENGTH_LONG).show();
            return;
        }

        Uri pdfUri = result.getPdf().getUri();
        int pageCount = result.getPdf().getPageCount();
        savePdfToDownloads(pdfUri, pageCount);
    }

    private void savePdfToDownloads(Uri sourceUri, int pageCount) {
        String fileName = "BookClean_" + pageCount + "_pages.pdf";
        ContentResolver resolver = getContentResolver();
        Uri output = null;

        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BookClean");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                output = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (output == null) throw new IllegalStateException("Could not create download");

                try (InputStream in = resolver.openInputStream(sourceUri);
                     OutputStream out = resolver.openOutputStream(output)) {
                    if (in == null || out == null) throw new IllegalStateException("Could not open PDF");
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(output, done, null, null);
            } else {
                java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/BookClean");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Could not create folder");
                java.io.File file = new java.io.File(dir, fileName);
                try (InputStream in = resolver.openInputStream(sourceUri);
                     OutputStream out = new java.io.FileOutputStream(file)) {
                    if (in == null) throw new IllegalStateException("Could not open PDF");
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                }
            }

            status.setText(getString(R.string.saved) + "\n" + fileName);
            Toast.makeText(this, "Saved " + pageCount + " pages", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            status.setText("");
            Toast.makeText(this, getString(R.string.failed) + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
            if (output != null) resolver.delete(output, null, null);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
